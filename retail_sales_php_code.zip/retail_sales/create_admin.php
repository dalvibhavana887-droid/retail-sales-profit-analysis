<?php
require 'db.php';
$username = 'admin';
$password = password_hash('Admin@123', PASSWORD_DEFAULT);
$stmt = $conn->prepare("SELECT id FROM users WHERE username=?");
$stmt->bind_param("s", $username); $stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
 echo "Admin already exists. Username: admin";
} else {
 $stmt = $conn->prepare("INSERT INTO users(username,password) VALUES(?,?)");
 $stmt->bind_param("ss", $username, $password);
 if ($stmt->execute()) echo "Admin created. Username: admin | Password: Admin@123. Delete create_admin.php now.";
 else echo "Could not create admin.";
}
?>