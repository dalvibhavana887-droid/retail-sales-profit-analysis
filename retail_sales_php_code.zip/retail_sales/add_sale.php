<?php
require 'auth.php'; require 'db.php';
$id=(int)($_GET['id']??0); $p='';$cat='Electronics';$qty=1;$price='';$cost='';$date=date('Y-m-d');$error='';
if($id){$st=$conn->prepare("SELECT * FROM sales WHERE id=?");$st->bind_param("i",$id);$st->execute();$old=$st->get_result()->fetch_assoc();if(!$old){header('Location: sales.php');exit;}$p=$old['product_name'];$cat=$old['category'];$qty=$old['quantity'];$price=$old['price'];$cost=$old['cost'];$date=$old['sale_date'];}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $p=trim($_POST['product_name']??'');$cat=trim($_POST['category']??'');$qty=(int)($_POST['quantity']??0);$price=(float)($_POST['price']??-1);$cost=(float)($_POST['cost']??-1);$date=$_POST['sale_date']??'';
 if($p===''||$cat===''||$qty<1||$price<0||$cost<0||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))$error='Please enter valid values.';
 else if($id){$st=$conn->prepare("UPDATE sales SET product_name=?,category=?,quantity=?,price=?,cost=?,sale_date=? WHERE id=?");$st->bind_param("ssiddsi",$p,$cat,$qty,$price,$cost,$date,$id);if($st->execute()){header('Location: sales.php');exit;}else $error='Could not update record.';}
 else {$st=$conn->prepare("INSERT INTO sales(product_name,category,quantity,price,cost,sale_date) VALUES(?,?,?,?,?,?)");$st->bind_param("ssidds",$p,$cat,$qty,$price,$cost,$date);if($st->execute()){header('Location: sales.php');exit;}else $error='Could not save record.';}
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Add Sale</title><link rel="stylesheet" href="style.css"></head><body><header><h1><?=$id?'Edit Sale':'Add Sale'?></h1><nav><a href="index.php">Dashboard</a><a href="sales.php">Sales Records</a><a href="logout.php">Logout</a></nav></header><main class="panel form"><?php if($error): ?><p class="error"><?=htmlspecialchars($error)?></p><?php endif; ?><form method="post">
<label>Product name</label><input name="product_name" required value="<?=htmlspecialchars((string)$p)?>">
<label>Category</label><select name="category"><?php foreach(['Electronics','Accessories','Furniture','Office Supplies','Clothing','Other'] as $x): ?><option <?=$cat===$x?'selected':''?>><?=$x?></option><?php endforeach; ?></select>
<label>Quantity</label><input type="number" min="1" name="quantity" required value="<?=$qty?>">
<label>Selling price per unit (₹)</label><input type="number" min="0" step="0.01" name="price" required value="<?=htmlspecialchars((string)$price)?>">
<label>Cost per unit (₹)</label><input type="number" min="0" step="0.01" name="cost" required value="<?=htmlspecialchars((string)$cost)?>">
<label>Sale date</label><input type="date" name="sale_date" required value="<?=htmlspecialchars((string)$date)?>">
<button><?=$id?'Update Sale':'Save Sale'?></button></form></main></body></html>