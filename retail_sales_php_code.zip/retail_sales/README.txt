RETAIL SALES AND PROFIT ANALYSIS — PHP + MYSQL (XAMPP)

FILES
- login.php       Login page
- index.php       Dashboard with sales/profit totals and charts
- sales.php       View and search sales records; edit and delete
- add_sale.php    Add or edit a sale record
- delete_sale.php Delete a sale record
- db.php          MySQL connection
- auth.php        Session login protection
- logout.php      Log out
- setup.sql       Database and sample sales records
- style.css       Website styling
- create_admin.php One-time demo admin creator

INSTALLATION ON WINDOWS
1. Start XAMPP Control Panel.
2. Click Start beside Apache and MySQL. Both must be running.
3. Extract this ZIP. Copy the project folder named retail_sales into:
   C:\xampp\htdocs\
   Final path should be C:\xampp\htdocs\retail_sales\login.php
4. Open http://localhost/phpmyadmin
5. Click Import, choose the file:
   C:\xampp\htdocs\retail_sales\setup.sql
   Then click Import/Go to run it. Alternatively, open the SQL tab and paste
   the setup.sql contents.
6. Open http://localhost/retail_sales/create_admin.php once to create the demo account.
7. Delete create_admin.php from C:\xampp\htdocs\retail_sales after the account is created.
8. Open http://localhost/retail_sales/login.php

DEMO LOGIN
Username: admin
Password: Admin@123

DATABASE SETTINGS
By default, db.php connects to MySQL as user root with a blank password, which is the
usual local XAMPP setup. If you configured a MySQL password, update db.php.

CALCULATIONS
Sales Amount = Quantity × Selling Price per Unit
Profit = Quantity × (Selling Price per Unit − Cost per Unit)
Profit Margin = Total Profit / Total Sales × 100

The charts use Chart.js from a CDN, so an internet connection is required for charts.
This is a classroom/demo project. Change demo credentials before any real deployment.
