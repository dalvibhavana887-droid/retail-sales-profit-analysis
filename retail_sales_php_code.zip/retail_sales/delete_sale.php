<?php
require 'auth.php'; require 'db.php';
if($_SERVER['REQUEST_METHOD']==='POST'){$id=(int)($_POST['id']??0);if($id){$st=$conn->prepare("DELETE FROM sales WHERE id=?");$st->bind_param("i",$id);$st->execute();}}
header('Location: sales.php'); exit;
?>