<?php
session_start(); require 'db.php';
if (isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 $username = trim($_POST['username'] ?? ''); $password = $_POST['password'] ?? '';
 $stmt = $conn->prepare("SELECT id,username,password FROM users WHERE username=?");
 $stmt->bind_param("s",$username); $stmt->execute();
 $user = $stmt->get_result()->fetch_assoc();
 if ($user && password_verify($password,$user['password'])) {
  session_regenerate_id(true); $_SESSION['user_id']=$user['id']; $_SESSION['username']=$user['username'];
  header('Location: index.php'); exit;
 }
 $error = 'Invalid username or password.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Retail Sales Login</title><link rel="stylesheet" href="style.css"></head>
<body class="login-page"><main class="login-card"><div class="logo">RS</div><h1>Retail Sales</h1><p class="muted">Sales &amp; Profit Analysis</p>
<?php if($error): ?><p class="error"><?=htmlspecialchars($error)?></p><?php endif; ?>
<form method="post"><label>Username</label><input name="username" required autocomplete="username"><label>Password</label><input type="password" name="password" required autocomplete="current-password"><button>Login</button></form>
<p class="muted small">Local mini project</p></main></body></html>