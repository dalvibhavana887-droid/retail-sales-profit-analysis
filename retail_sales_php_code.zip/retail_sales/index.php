<?php
require 'auth.php'; require 'db.php';
$s=$conn->query("SELECT COALESCE(SUM(quantity*price),0) sales, COALESCE(SUM(quantity*(price-cost)),0) profit, COUNT(*) records FROM sales")->fetch_assoc();
$sales=(float)$s['sales']; $profit=(float)$s['profit']; $margin=$sales?($profit/$sales*100):0;
$cq=$conn->query("SELECT category,SUM(quantity*price) sales,SUM(quantity*(price-cost)) profit FROM sales GROUP BY category");
$cats=[]; while($r=$cq->fetch_assoc()) $cats[]=$r;
$mq=$conn->query("SELECT DATE_FORMAT(sale_date,'%Y-%m') month,SUM(quantity*price) sales,SUM(quantity*(price-cost)) profit FROM sales GROUP BY month ORDER BY month");
$months=[]; while($r=$mq->fetch_assoc()) $months[]=$r;
function cash($n){return '₹'.number_format((float)$n,2);}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Retail Dashboard</title><link rel="stylesheet" href="style.css"><script src="https://cdn.jsdelivr.net/npm/chart.js"></script></head><body>
<header><h1>Retail Sales &amp; Profit Dashboard</h1><p>Welcome, <?=htmlspecialchars($_SESSION['username'])?> | <a href="logout.php">Logout</a></p><nav><a href="index.php">Dashboard</a><a href="sales.php">Sales Records</a><a href="add_sale.php">Add Sale</a></nav></header>
<div class="cards"><article><span>Total Sales</span><h2><?=cash($sales)?></h2></article><article><span>Total Profit</span><h2><?=cash($profit)?></h2></article><article><span>Profit Margin</span><h2><?=number_format($margin,2)?>%</h2></article><article><span>Sales Records</span><h2><?=$s['records']?></h2></article></div>
<div class="charts"><article><h3>Sales by Category</h3><canvas id="salesChart"></canvas></article><article><h3>Profit by Category</h3><canvas id="profitChart"></canvas></article><article class="wide"><h3>Monthly Sales and Profit</h3><canvas id="monthlyChart"></canvas></article></div>
<script>
const c=<?=json_encode($cats)?>,m=<?=json_encode($months)?>;
new Chart(document.getElementById('salesChart'),{type:'doughnut',data:{labels:c.map(x=>x.category),datasets:[{data:c.map(x=>Number(x.sales))}]},options:{responsive:true}});
new Chart(document.getElementById('profitChart'),{type:'bar',data:{labels:c.map(x=>x.category),datasets:[{label:'Profit',data:c.map(x=>Number(x.profit))}]},options:{responsive:true}});
new Chart(document.getElementById('monthlyChart'),{type:'line',data:{labels:m.map(x=>x.month),datasets:[{label:'Sales',data:m.map(x=>Number(x.sales))},{label:'Profit',data:m.map(x=>Number(x.profit))}]},options:{responsive:true}});
</script></body></html>