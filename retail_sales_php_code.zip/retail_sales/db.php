<?php
$conn = new mysqli("localhost", "root", "", "retail_sales_db");
if ($conn->connect_error) { die("Database connection failed. Check XAMPP MySQL."); }
$conn->set_charset("utf8mb4");
?>