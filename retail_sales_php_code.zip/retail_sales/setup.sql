CREATE DATABASE IF NOT EXISTS retail_sales_db;
USE retail_sales_db;
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS sales (
 id INT AUTO_INCREMENT PRIMARY KEY,
 product_name VARCHAR(100) NOT NULL,
 category VARCHAR(50) NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(12,2) NOT NULL,
 cost DECIMAL(12,2) NOT NULL,
 sale_date DATE NOT NULL
);
INSERT INTO sales (product_name,category,quantity,price,cost,sale_date)
SELECT 'Laptop','Electronics',2,50000,40000,'2026-10-01'
WHERE NOT EXISTS (SELECT 1 FROM sales);
INSERT INTO sales (product_name,category,quantity,price,cost,sale_date)
SELECT 'Mouse','Accessories',10,500,300,'2026-10-02'
WHERE (SELECT COUNT(*) FROM sales)=1;
INSERT INTO sales (product_name,category,quantity,price,cost,sale_date)
SELECT 'Keyboard','Accessories',5,1200,800,'2026-10-03'
WHERE (SELECT COUNT(*) FROM sales)=2;
INSERT INTO sales (product_name,category,quantity,price,cost,sale_date)
SELECT 'Monitor','Electronics',3,12000,9500,'2026-10-04'
WHERE (SELECT COUNT(*) FROM sales)=3;
INSERT INTO sales (product_name,category,quantity,price,cost,sale_date)
SELECT 'Chair','Furniture',4,3500,2800,'2026-10-05'
WHERE (SELECT COUNT(*) FROM sales)=4;
